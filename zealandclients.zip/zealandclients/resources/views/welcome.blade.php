@extends('layouts.app')

@section('content')


 

          <div class="container">
          <div class="row">  
               
               <div   id="space">
                    <h3 class="fhead">Products</h3>
                 <a href="/product">
                 <img Style="height:400px; width:1000px;" src="https://www.shopivo.com/blog/wp-content/uploads/2019/08/Non-Physical-Products-Header.png" alt="">
                 </a>
               </div>

               <div   id="space">
               <h3 class="fhead">Clothes</h3>
                 <a href="/product/catogery/1">
                 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSYq8AXeoVZEDDrf0DGA_h1Qj960SMgdoOmwDhVNKMy631u7P43&usqp=CAU" alt="">
                 </a>
               </div>
     

               <div  id="space">
               <h3 class="fhead">Food</h3>
                 <a href="/product/catogery/2">
                 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR1Bu2CepbFGbUob-aPuLgSRUdnn0Ywyj6GTo6wHcwGr57zMvP0&usqp=CAU" alt="">
                 </a>
               </div>


               <div   id="space">
               <h3 class="fhead">Electronic</h3>
                 <a href="/product/catogery/3">
                 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS5pU36LIpUnwyZho5cy53UmfTNfqnHzA6R3s7hT2p_OYQVVJWh&usqp=CAU" alt="">
                 </a>
               </div>

          </div>
          </div>



        @endsection

