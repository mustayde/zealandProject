<?php $__env->startSection('content'); ?>
        <div class="flex-center position-ref full-height">

            <div class="content">
                <div class="container detailMargin oShadow">
                    <div class="row">
                        <div class="col">
                            <div class="row" style="height: 100%">
                                <div class="col" style="position: relative">
                                <h2><?php echo e($prod['products']['name']); ?></h2>
                                <p><?php echo e($prod['products']['description']); ?></p>
                                    <div class="textBotl">
                                        <h3 ><?php echo e($prod['products']['price']); ?> Kr.</h3>
                                        <h6><?php echo e($prod['products']['discount']); ?>% Discount</h6>
                                    </div>
                                </div>
                                <div class="col" style="position: relative">
                                    <div class="textBotr">
                                        <p><?php echo e($prod['products']['stock']); ?> Stk.</p>
                                        <p>From <?php echo e($prod['products']['brand']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col">
                            <img class="mx-auto d-block" src="<?php echo e($prod['products']['image']); ?>" style="height: 400px" >
                        </div>
                    </div>
                </div>



            <?php if( auth()->check() ): ?>



        <div class="container detailMargin oShadow">
        <h1>Add to cart</h1>
            <form method="POST" action="/product/cart">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="no_items">Cart</label>
            <input type="text" class="form-control" id="no_items" name="no_items">
        </div>
        <?php $__errorArgs = ['no_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <div class="alert alert-danger"><?php echo e($message); ?></div>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <div class="form-group">
            <button style="cursor:pointer" type="submit" class="btn btn-primary">Submit</button>
        </div>

     </form>
        </div>

     <!--  REVIEW  -->
        <div class="container detailMargin oShadow">
     <h2>Review</h2>
     <form method="POST" action="/product/review">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="review">Review</label>
            <input type="text" class="form-control" id="review" name="review">
        </div>
        <?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <div class="alert alert-danger"><?php echo e($message); ?></div>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-group">
             <input type="hidden" class="form-control"  value="<?php echo e(auth()->user()->username); ?>" id="username" name="username" >
        </div>

        <div class="form-group">
             <input type="hidden" class="form-control" id="product_id" name="product_id" value="<?php echo e($id); ?>">
        </div>

        <div class="form-group">
            <button style="cursor:pointer" type="submit" class="btn btn-primary">Submit</button>
        </div>

     </form>
        </div>
       <?php endif; ?>

                <div class="container detailMargin oShadow">
       <h2>Reviews</h2>
                  <?php if($prod['reviews']): ?>
                  <?php $__currentLoopData = $prod['reviews']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pizza-item">
                    <h4><?php echo e($produc['username']); ?></h4>
                    <p><?php echo e($produc['review']); ?></p>


                  </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php else: ?>
                 <div class="pizza-item">
                  <p>No review yet</p>
                  </div>
         <?php endif; ?>
                </div>

            <div class="container detailMargin oShadow">
            <h2>Related product</h2>


                    <div class="content" id="productGrid">


                        <?php if(is_array($cato) || is_object($cato)): ?>
                            <?php $__currentLoopData = $cato['catogories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card oShadow" id="productMargin" style="width: 22rem;">
                                    <a href="/product/<?php echo e($produc['id']); ?>" style="color: black; text-decoration: none;">
                                        <img class="card-img-top" src="<?php echo e($produc['image']); ?>" style="height: 280px; object-fit: cover;" >
                                        <div class="card-body" id="productDesc">
                                            <h4><?php echo e($produc['name']); ?></h4>
                                            <h4><?php echo e($produc['description']); ?></h4>
                                            <h4><?php echo e($produc['price']); ?> Kr.</h4>
                                        </div>

                                    </a>
                                </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                    </div>

            </div>
        </div>

        <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harman\zealandclients\resources\views/detailproduct.blade.php ENDPATH**/ ?>