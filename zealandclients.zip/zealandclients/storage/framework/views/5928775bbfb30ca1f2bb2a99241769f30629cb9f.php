

<?php $__env->startSection('content'); ?>
 
    <h2 id="log">Log In</h2>
    
    <form id="update-form" method="POST" action="/login">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="email" class="form-control" id="email" name="email" placeholder="Email..">
        </div>
 
        <div class="form-group">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password..">
        </div>
 
        <div class="form-group">
            <button style="cursor:pointer" type="submit" class="btn btn-primary">Login</button>
        </div>
        <?php echo $__env->make('partials.formerrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hoca/Desktop/webdevelopment/Zealand Webshop Final one/zealandclients/resources/views/sessions/create.blade.php ENDPATH**/ ?>