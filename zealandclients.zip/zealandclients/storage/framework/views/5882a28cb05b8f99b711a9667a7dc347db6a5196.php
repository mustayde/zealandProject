

<?php $__env->startSection('content'); ?>
<div class="view-header">Top suppliers of the week</div>
<table class="table">
  <thead class="thead-dark">
    <tr>
       <th scope="col">Supplier Name</th>
      <th scope="col">Total Products</th>
     </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $view['suppliers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
       <td><?php echo e($produc['suppliername']); ?></td>
       <td><?php echo e($produc['COUNT']); ?></td>
      </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div class="add-product">
      <a href="/suppliermanager">Add new supplier</a>
</div>


<div class="d-flex flex-wrap">

  <?php if(is_array($supplier) || is_object($supplier)): ?>
  <?php $__currentLoopData = $supplier['suppliers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <a href="/suppliermanagerview/<?php echo e($produc['id']); ?>">

  <div class="d-flex flex-lg-wrap oShadow">
    <div class="test">
  <div class="all-info">Name - <?php echo e($produc['suppliername']); ?></div>
  <div class="all-info">Email - <?php echo e($produc['email']); ?></div>
  <div class="all-info">Company - <?php echo e($produc['company']); ?></div>
  </a>

  <form action="/suppliermanager/<?php echo e($produc['id']); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button class="delete-btn">Delete supplier</button>
    </form>

    </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harman\zealandclients\resources\views/admin/deletesupplier.blade.php ENDPATH**/ ?>