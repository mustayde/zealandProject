

<?php $__env->startSection('content'); ?>
<div class="view-header">Top products of the week</div>
<table class="table">
  <thead class="thead-dark">
    <tr>
       <th scope="col">Products</th>
      <th scope="col">Total Review</th>
     </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $view['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
       <td><?php echo e($produc['name']); ?></td>
       <td><?php echo e($produc['COUNT']); ?></td>
      </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div class="add-product">
      <a href="/admin">Add new product</a>
</div>


<div class="d-flex flex-wrap ">
        <?php if(is_array($product) || is_object($product)): ?>
        <?php $__currentLoopData = $product['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/adminview/<?php echo e($produc['id']); ?>">
            <div class="d-flex flex-lg-wrap oShadow ">
              <div class="test">
                  <img src="<?php echo e($produc['image']); ?>" style="height: 200px" ></img>
                  <div class="all-info">Name - <?php echo e($produc['name']); ?></div>
                  <div class="all-info">Description - <?php echo e($produc['description']); ?></div>
                  <div class="all-info">Price - <?php echo e($produc['price']); ?> kr</div>
                  </a>
                  <form action="/adminview/<?php echo e($produc['id']); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    <button class="delete-btn">Delete product</button>
                  </form> 
              </div>
              </div>
         
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>       
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harman\zealandclients\resources\views/admin/crudproducts1.blade.php ENDPATH**/ ?>