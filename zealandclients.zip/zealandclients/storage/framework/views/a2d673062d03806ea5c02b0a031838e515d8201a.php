<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Zealand Webshop</title>
        
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="/css/main.css" rel="stylesheet">
        <link href="/css/adem.css" rel= "stylesheet">
       <link href="/css/oliver.css" rel= "stylesheet">
    </head>
<body>
    
    <nav class="navbar">

    <a class="navbar-brand" href="/">Zealand</a>
 
    <div class="ko">
        <ul class="nav justify-content-center">
          <?php if( auth()->check() ): ?>
             <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="">Hi <?php echo e(auth()->user()->name); ?></a>
                </li> 
                <?php endif; ?>
                 <li class="nav-item">
                <a class="nav-link" href="/">Products</a>
              </li>
              <?php if( auth()->check() ): ?>
              <?php if( auth()->user()->role === 'supplier' ): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/supplierview">Supplier's products view</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/cart">Cart</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/logout">Log Out</a>
                </li>
                <?php endif; ?>
                <?php if( auth()->user()->role === 'admin' ): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/suppliermanagerview">All Suppliers View</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/adminview">All Products View</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/cart">Cart</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/logout">Log Out</a>
                </li>
                <?php endif; ?>
                <?php if( auth()->user()->role === 'user' ): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/cart">Cart</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/logout">Log Out</a>
                </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="/login">Log In</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/register">Register</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>


<?php echo $__env->make('partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4"  >
            <?php echo $__env->yieldContent('content'); ?>
  

        </main>


             
        <div id="page-container">
  <div id="content-wrap">
   </div>
  <footer>
       <p>COPYRIGHT TO OMAH 2020</p>
     </footer>
   </div>
       

</body>
</html>
<?php /**PATH /Users/hoca/Desktop/webdevelopment/Zealand Webshop Final one/zealandclients/resources/views/layouts/app.blade.php ENDPATH**/ ?>