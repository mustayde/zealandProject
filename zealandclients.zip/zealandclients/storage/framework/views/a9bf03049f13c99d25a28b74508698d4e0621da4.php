<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Categorized Products</h1>
        <div class="content" id="productGrid">


            <?php if(is_array($prod) || is_object($prod)): ?>
            <?php $__currentLoopData = $prod['catogories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card oShadow" style="width: 22rem;" id="productMargin">
            <a href="/product/<?php echo e($produc['id']); ?>" style="color: black; text-decoration: none;">


                <img class="card-img-top" src="<?php echo e($produc['image']); ?>" style="height: 280px; object-fit: cover;" >
                <div class="card-body" id="productDesc">

                    <h3><?php echo e($produc['name']); ?></h3>
                    <p><?php echo e($produc['description']); ?></p>
                    <h4><?php echo e($produc['price']); ?> Kr.</h4>
                </div>
            </a>
        </div>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harman\zealandclients\resources\views/catogery.blade.php ENDPATH**/ ?>