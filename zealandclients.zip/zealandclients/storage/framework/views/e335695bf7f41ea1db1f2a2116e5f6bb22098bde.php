<?php if($message = session('message')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?>"><?php echo $message; ?></div>
<?php endif; ?><?php /**PATH /Users/hoca/Desktop/webdevelopment/Zealand Webshop Final one/zealandclients/resources/views/partials/flash.blade.php ENDPATH**/ ?>