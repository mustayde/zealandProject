<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Topproducts extends Model
{
    //
}
